-- MySQL dump 10.13  Distrib 8.0.43, for macos15 (x86_64)
--
-- Host: localhost    Database: civil_app
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_project_building_tower`
--

DROP TABLE IF EXISTS `tbl_project_building_tower`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_project_building_tower` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_sync_at` datetime(3) DEFAULT NULL,
  `project_id` int NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_project_building_tower_slug_key` (`slug`),
  KEY `idx_building_tower_project` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_project_building_tower`
--

LOCK TABLES `tbl_project_building_tower` WRITE;
/*!40000 ALTER TABLE `tbl_project_building_tower` DISABLE KEYS */;
INSERT INTO `tbl_project_building_tower` VALUES (7,'Ahan C1 Tower','1-ahan-c1-tower','2025-10-05 04:18:14.000',1,'2025-11-19 04:11:07.668','2025-11-19 04:11:07.668'),(8,'Ahan C2 Tower','1-ahan-c2-tower','2025-10-05 04:18:14.000',1,'2025-11-19 04:11:07.669','2025-11-19 04:11:07.669'),(9,'Arav','1-arav','2025-10-05 04:18:14.000',1,'2025-11-19 04:11:07.670','2025-11-19 04:11:07.670'),(10,'Mahalaxmi C1 Tower','2-mahalaxmi-c1-tower','2025-10-05 04:18:14.000',2,'2025-11-19 04:11:07.671','2025-11-19 04:11:07.671'),(11,'Mahalaxmi C2 Tower','2-mahalaxmi-c2-tower','2025-10-05 04:18:14.000',2,'2025-11-19 04:11:07.672','2025-11-19 04:11:07.672'),(12,'Mahalaxmi','2-mahalaxmi','2025-10-05 04:18:14.000',2,'2025-11-19 04:11:07.673','2025-11-19 04:11:07.673');
/*!40000 ALTER TABLE `tbl_project_building_tower` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-21  9:39:56
